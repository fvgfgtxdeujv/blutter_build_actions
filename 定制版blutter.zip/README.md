# B(l)utter

Flutter 应用逆向分析工具（通过编译 Dart AOT Runtime 实现）。

当前仅支持 Android 的 `libapp.so`（arm64）。

## 依赖

运行 `blutter.py` 需要以下 Python 包：

```bash
pip install pyelftools requests
```

## 使用方法

直接解析 APK：

```bash
python3 blutter.py path/to/app.apk out_dir
```

或解析已解压的 lib 目录（需包含 `libapp.so` 和 `libflutter.so`）：

```bash
python3 blutter.py path/to/app/lib/arm64-v8a out_dir
```

`blutter.py` 会从 APK / lib 中自动检测 Dart 版本，然后在 `bin` 目录查找对应版本的 blutter 可执行文件：

- **找到对应版本**：直接运行解析，输出到 `out_dir`
- **未找到**：
  - 先确认系统为 Ubuntu 22.04 或 24.04，否则报错「当前系统或当前系统版本不支持，仅支持 Ubuntu 22.04 或 24.04」
  - 系统受支持时，自动从 blutter 构建仓库的 Releases 下载匹配的二进制（自动识别 22.04 / 24.04，下载带 `_22` / `_24` 后缀的版本，重命名为无后缀格式放入 `bin`），随后自动继续解析
  - 若下载失败，则打印所需版本号，提示手动下载放入 `bin` 目录后重新运行

`bin` 目录下可执行文件命名格式：

```
blutter_dartvm<版本>_android_arm64
```

例如 Dart 3.4.2 对应 `blutter_dartvm3.4.2_android_arm64`。若需手动下载，请从 `fvgfgtxdeujv/blutter_build_actions` 仓库的 Releases 获取（构建产物可能带 `_22` / `_24` 后缀，可重命名为无后缀格式放入 `bin`）。

## 输出文件

运行 blutter 后，`out_dir` 中生成：

- **asm/*** libapp 反汇编文件（含符号信息）
- **blutter_frida.js** 针对目标应用的 Frida 脚本模板
- **objs.txt** Object Pool 中对象的完整（嵌套）转储
- **pp.txt** Object Pool 中所有 Dart 对象

## 目录结构

- **bin** 各 Dart 版本的 blutter 可执行文件（命名格式见上）
- **scripts** 运行时所需的 Frida 脚本模板（`frida.template.js`）
