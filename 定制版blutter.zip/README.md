# B(l)utter 定制版（精简运行包）

Flutter 应用逆向分析工具，基于 [blutter](https://github.com/worawit/blutter) 定制构建（二进制由 GitHub Actions 自动产出）。

支持的目标形态：

- **Android**：`libapp.so` / APK（arm64）
- **Flutter Windows 桌面**：`data/app.so` + `flutter_windows.dll`（x64，需在 Windows 宿主运行）

不适配 iOS / macOS（本项目目标范围明确排除，输入 `.ipa`、iOS `App` 或 Mac 宿主均不支持）。

## 依赖

```bash
pip install pyelftools requests
```

## 使用方法

```bash
# Android：直接解析 APK
python3 blutter.py path/to/app.apk out_dir

# Android：解析已解压的 lib 目录（含 libapp.so 与 libflutter.so）
python3 blutter.py path/to/app/lib/arm64-v8a out_dir

# Flutter Windows 桌面：应用目录或 app.so 路径（Windows 宿主）
python3 blutter.py C:\path\to\app out_dir
```

`blutter.py` 会自动检测目标类型与 Dart 版本，然后在 `$HOME/blutter/bin` 查找匹配的 blutter 可执行文件：

- **找到对应版本**：直接运行解析
- **未找到**（或指定 `--rebuild`）：
  - 默认优先从 Releases 远程下载预编译二进制：Windows 宿主下载 `_win.exe` 产物，并在首次运行时补齐 `capstone.dll` / `icuuc73.dll` / `icudt73.dll`；Ubuntu 22.04 / 24.04 下载对应 `_22` / `_24` 产物（识别系统版本，落盘为无后缀命名）
  - 下载不可用或失败，且处于完整源码仓库检出（`scripts/build.py` 与 `blutter/` 就位）：用定制版 `blutter/src` 从源码构建 dartvm + blutter，构建产物落到 `$HOME/blutter/bin`
  - 指定 `--rebuild`：跳过下载，强制从源码构建
  - 源码不完整（例如只解压了本运行包）且下载失败：打印所需版本，提示手动放入 `bin` 目录
  - Flutter Windows 桌面目标出现在 Linux 宿主：直接提示需在 Windows 宿主运行

下载源按国内/国外网络自动选择（中文语言、国内时区、GitHub 实测延迟三信号打分）：国内优先 Gitee 镜像 `qeruiop_admin/blutter_build_actions`，否则优先 GitHub `fvgfgtxdeujv/blutter_build_actions`，主源失败自动切换备选源。

## 从源码构建（可选）

把本包解压到 blutter 源码仓库根目录（或直接在完整检出中运行 `blutter.py`），并在仓库根执行：

```bash
# 默认优先下载；下载失败才自动从源码构建。用 --rebuild 跳过下载、强制重建
python3 blutter.py path/to/app.apk out_dir --rebuild
```

构建复用仓库内 `scripts/build.py` 的四步（`clone-dart → generate-sources → build-dartvm → build-blutter`），在 Debian 等缺少 `std::format` 的发行版上会自动改用 clang-16 + libc++ 工具链。源码构建仅支持默认变体（含代码分析）；`--no-analysis` 等变体仍走下载。构建前需已安装 `cmake` / `ninja` / `git` / `clang-16` / `libc++-16-dev` / `libc++abi-16-dev` / `libcapstone-dev` / `libicu-dev` / `ccache` 等依赖（Debian/Ubuntu：`apt-get install -y cmake ninja-build git clang-16 libc++-16-dev libc++abi-16-dev libcapstone-dev libicu-dev ccache`）。

## 可选参数

| 参数 | 说明 |
|------|------|
| `--blacklist <file>` | 语义线索黑名单文件，透传给 blutter 二进制，可读时整体替换内置默认（`$BLUTTER_BLACKLIST` 环境变量同样生效）；需使用 2026-09 之后构建的 `_22`/`_24`/`_win.exe` 产物 |
| `--rebuild` | 强制从源码重建 blutter 可执行文件（需完整仓库检出：`scripts/build.py` + `blutter/`）；默认仅在缺失匹配二进制且仓库完整时自动构建 |
| `--no-analysis` | 选择 no-analysis 变体产物 |
| `--dart-version <v>_<os>_<arch>` | 无 libflutter 时手动指定，如 `3.4.2_android_arm64`、`3.3.4_windows_x64`（仅支持 android/windows） |

## 输出文件

- **asm/** libapp 反汇编（含 `// semantic:` 业务语义注释）
- **objs.txt / pp.txt** Object Pool 对象转储
- **strings_to_funcs.txt** 字符串 → 函数交叉引用表
- **ida_script/** IDA 加载脚本目录：`addNames.py`（含混淆函数语义化重命名 `fn_*`）、`semantic_names.txt`（重命名追踪表）等
- **blutter_frida.js / blutter_frida_windows.js** Frida 动态 dump 脚本：Android 目标生成前者，Windows 桌面 x64 目标生成后者（非压缩指针 + 栈参数 ABI + 代码段多锚点 base 发现；真实设备 attach 前请人工复核）

针对混淆应用：函数体大小会被扫描恢复，业务函数在 IDA 中加载 `addNames.py` 即得可读名（如 `fn_startVpn`）。

## 二进制命名格式

```
blutter_dartvm<版本>_android_arm64[_22|_24|_win.exe]
blutter_dartvm<版本>_windows_x64_win.exe
```

## 目录结构

- **bin**（即 `$HOME/blutter/bin`）各 Dart 版本的 blutter 可执行文件与 Windows 运行 dll
- **scripts** 运行时所需的 Frida 脚本模板（`frida.template.js`、`frida.windows.template.js`）
