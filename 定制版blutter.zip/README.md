# B(l)utter

Flutter 应用逆向分析工具（通过编译 Dart AOT Runtime 实现）。

当前仅支持 Android 的 `libapp.so`（arm64）。

## 依赖

运行 `blutter.py` 需要以下 Python 包：

```bash
pip install pyelftools requests
```

## 使用方法

直接解析 APK：

```bash
python3 blutter.py path/to/app.apk out_dir
```

或解析已解压的 lib 目录（需包含 `libapp.so` 和 `libflutter.so`）：

```bash
python3 blutter.py path/to/app/lib/arm64-v8a out_dir
```

`blutter.py` 会从 APK / lib 中自动检测 Dart 版本，然后在 `bin` 目录查找对应版本的 blutter 可执行文件：

- **找到对应版本**：直接运行解析，输出到 `out_dir`
- **未找到**：打印所需的 Dart 版本号，并提示从 blutter 构建仓库的 Releases 下载对应版本二进制放入 `bin` 目录，之后重新运行命令即可

`bin` 目录下可执行文件命名格式：

```
blutter_dartvm<版本>_android_arm64
```

例如 Dart 3.4.2 对应 `blutter_dartvm3.4.2_android_arm64`。

## 输出文件

运行 blutter 后，`out_dir` 中生成：

- **asm/*** libapp 反汇编文件（含符号信息）
- **blutter_frida.js** 针对目标应用的 Frida 脚本模板
- **objs.txt** Object Pool 中对象的完整（嵌套）转储
- **pp.txt** Object Pool 中所有 Dart 对象

## 目录结构

- **bin** 各 Dart 版本的 blutter 可执行文件（命名格式见上）
- **scripts** 运行时所需的 Frida 脚本模板（`frida.template.js`）
