#!/usr/bin/python3
import argparse
import glob
import io
import mmap
import os
import platform
import re
import shutil
import subprocess
import sys
import zipfile
import tempfile
import zlib
from struct import unpack

import requests

from elftools.elf.elffile import ELFFile
from elftools.elf.enums import ENUM_E_MACHINE
from elftools.elf.sections import SymbolTableSection

CMAKE_CMD = "cmake"
NINJA_CMD = "ninja"

class DartLibInfo:
    def __init__(self, version: str, os_name: str, arch: str, has_compressed_ptrs = None, snapshot_hash = None):
        self.version = version
        self.os_name = os_name
        self.arch = arch
        self.snapshot_hash = snapshot_hash
        if has_compressed_ptrs is None:
            self.has_compressed_ptrs = os_name != 'ios'
        else:
            self.has_compressed_ptrs = has_compressed_ptrs
        self.lib_name = f'dartvm{version}_{os_name}_{arch}'

SCRIPT_DIR = os.path.dirname(os.path.realpath(__file__))
# 二进制固定存放目录（Android 手机端，$HOME/blutter/bin）
BIN_DIR = os.path.join(os.path.expanduser('~'), 'blutter', 'bin')
PKG_INC_DIR = os.path.join(SCRIPT_DIR, 'packages', 'include')
PKG_LIB_DIR = os.path.join(SCRIPT_DIR, 'packages', 'lib')
BUILD_DIR = os.path.join(SCRIPT_DIR, 'build')


class BlutterInput:
    def __init__(self, libapp_path: str, dart_info: DartLibInfo, outdir: str, rebuild_blutter: bool, create_vs_sln: bool, no_analysis: bool):
        self.libapp_path = libapp_path
        self.dart_info = dart_info
        self.outdir = outdir
        self.rebuild_blutter = rebuild_blutter
        self.create_vs_sln = create_vs_sln

        vers = dart_info.version.split('.', 2)
        if int(vers[0]) == 2 and int(vers[1]) < 15:
            if not no_analysis:
                print('Dart version <2.15, force "no-analysis" option')
            no_analysis = True
        self.no_analysis = no_analysis

        # Note: null-safety is detected in blutter application, so no need another build of blutter for null-safety
        self.name_suffix = ''
        if not dart_info.has_compressed_ptrs:
            self.name_suffix += '_no-compressed-ptrs'
        if no_analysis:
            self.name_suffix += '_no-analysis'
        # derive blutter executable filename
        self.blutter_name = f'blutter_{dart_info.lib_name}{self.name_suffix}'
        self.blutter_file = os.path.join(BIN_DIR, self.blutter_name) + ('.exe' if os.name == 'nt' else '')


# ========== Dart 版本信息提取 ==========

# TODO: support both ELF and Mach-O file
def extract_snapshot_hash_flags(libapp_file):
    with open(libapp_file, 'rb') as f:
        elf = ELFFile(f)
        # find "_kDartVmSnapshotData" symbol
        dynsym = elf.get_section_by_name('.dynsym')
        sym = dynsym.get_symbol_by_name('_kDartVmSnapshotData')[0]
        #section = elf.get_section(sym['st_shndx'])
        assert sym['st_size'] > 128
        f.seek(sym['st_value']+20)
        snapshot_hash = f.read(32).decode()
        data = f.read(256) # should be enough
        flags = data[:data.index(b'\0')].decode().strip().split(' ')
    
    return snapshot_hash, flags

def extract_libflutter_info(libflutter_file):
    with open(libflutter_file, 'rb') as f:
        elf = ELFFile(f)
        if elf.header.e_machine == 'EM_AARCH64': # 183
            arch = 'arm64'
        elif elf.header.e_machine == 'EM_IA_64': # 50
            arch = 'x64'
        else:
            assert False, f"Unsupport architecture: {elf.header.e_machine}"

        section = elf.get_section_by_name('.rodata')
        data = section.data()
        
        sha_hashes = re.findall(b'\x00([a-f\\d]{40})(?=\x00)', data)
        #print(sha_hashes)
        # all possible engine ids
        engine_ids = [ h.decode() for h in sha_hashes ]
        assert len(engine_ids) == 2, f'found hashes {", ".join(engine_ids)}'
        
        # beta/dev version of flutter might not use stable dart version (we can get dart version from sdk with found engine_id)
        # support stable, beta and dev channels
        m = re.search(br'\x00([\d\w\.-]+) \((stable|beta|dev)\)', data)
        if m is None:
            dart_version = None
        else:
            dart_version = m.group(1).decode()
        
    return engine_ids, dart_version, arch, 'android'

def get_dart_sdk_url_size(engine_ids):
    #url = f'https://storage.googleapis.com/dart-archive/channels/stable/release/3.0.3/sdk/dartsdk-windows-x64-release.zip'
    for engine_id in engine_ids:
        url = f'https://storage.googleapis.com/flutter_infra_release/flutter/{engine_id}/dart-sdk-windows-x64.zip'
        resp = requests.head(url)
        if resp.status_code == 200:
           sdk_size = int(resp.headers['Content-Length'])
           return engine_id, url, sdk_size
    
    return None, None, None

def get_dart_commit(url):
    # in downloaded zip
    # * dart-sdk/revision - the dart commit id of https://github.com/dart-lang/sdk/
    # * dart-sdk/version  - the dart version
    # revision and version zip file records should be in first 4096 bytes
    # using stream in case a server does not support range
    commit_id = None
    dart_version = None
    fp = None
    with requests.get(url, headers={"Range": "bytes=0-4096"}, stream=True) as r:
        if r.status_code // 10 == 20:
            x = next(r.iter_content(chunk_size=4096))
            fp = io.BytesIO(x)
    
    if fp is not None:
        while fp.tell() < 4096-30 and (commit_id is None or dart_version is None):
            _, _, _, compMethod, _, _, _, compressSize, _, filenameLen, extraLen = unpack('<IHHHHHIIIHH', fp.read(30))
            filename = fp.read(filenameLen)
            #print(filename)
            if extraLen > 0:
                fp.seek(extraLen, io.SEEK_CUR)
            data = fp.read(compressSize)
            
            # expect compression method to be zipfile.ZIP_DEFLATED
            assert compMethod == zipfile.ZIP_DEFLATED, 'Unexpected compression method'
            if filename == b'dart-sdk/revision':
                commit_id = zlib.decompress(data, wbits=-zlib.MAX_WBITS).decode().strip()
            elif filename == b'dart-sdk/version':
                dart_version = zlib.decompress(data, wbits=-zlib.MAX_WBITS).decode().strip()
    
    # TODO: if no revision and version in first 4096 bytes, get the file location from the first zip dir entries at the end of file (less than 256KB)
    return commit_id, dart_version

def extract_dart_info(libapp_file: str, libflutter_file: str):
    snapshot_hash, flags = extract_snapshot_hash_flags(libapp_file)
    #print('snapshot hash', snapshot_hash)
    #print(flags)

    engine_ids, dart_version, arch, os_name = extract_libflutter_info(libflutter_file)
    # print('possible engine ids', engine_ids)
    # print('dart version', dart_version)

    if dart_version is None:
        engine_id, sdk_url, sdk_size = get_dart_sdk_url_size(engine_ids)
        # print(engine_id)
        # print(sdk_url)
        # print(sdk_size)

        commit_id, dart_version = get_dart_commit(sdk_url)
        # print(commit_id)
        # print(dart_version)
        #assert dart_version == dart_version_sdk
    
    # TODO: os (android or ios) and architecture (arm64 or x64)
    return dart_version, snapshot_hash, flags, arch, os_name


def find_lib_files(indir: str):
    app_file = os.path.join(indir, 'libapp.so')
    if not os.path.isfile(app_file):
        app_file = os.path.join(indir, 'App')
        if not os.path.isfile(app_file):
            sys.exit("Cannot find libapp file")
    
    flutter_file = os.path.join(indir, 'libflutter.so')
    if not os.path.isfile(flutter_file):
        flutter_file = os.path.join(indir, 'Flutter')
        if not os.path.isfile(flutter_file):
            sys.exit("Cannot find libflutter file")
    
    return os.path.abspath(app_file), os.path.abspath(flutter_file)

def extract_libs_from_apk(apk_file: str, out_dir: str):
    with zipfile.ZipFile(apk_file, "r") as zf:
        try:
            app_info = zf.getinfo('lib/arm64-v8a/libapp.so')
            flutter_info = zf.getinfo('lib/arm64-v8a/libflutter.so')
        except:
            sys.exit("Cannot find libapp.so or libflutter.so in the APK")

        zf.extract(app_info, out_dir)
        zf.extract(flutter_info, out_dir)

        app_file = os.path.join(out_dir, app_info.filename)
        flutter_file = os.path.join(out_dir, flutter_info.filename)
        return app_file, flutter_file

def find_compat_macro(dart_version: str, no_analysis: bool):
    macros = []
    include_path = os.path.join(PKG_INC_DIR, f'dartvm{dart_version}')
    vm_path = os.path.join(include_path, 'vm')
    with open(os.path.join(vm_path, 'class_id.h'), 'rb') as f:
        mm = mmap.mmap(f.fileno(), 0, access = mmap.ACCESS_READ)
        # Rename the default implementation classes of Map and Set https://github.com/dart-lang/sdk/commit/a2de36e708b8a8e15d3bd49eef2cede57e649436
        if mm.find(b'V(LinkedHashMap)') != -1:
            macros.append('-DOLD_MAP_SET_NAME=1')
            # Add immutable maps and sets https://github.com/dart-lang/sdk/commit/e8e9e1d15216788d4112e40f4408c52455d11113
            if mm.find(b'V(ImmutableLinkedHashMap)') == -1:
                macros.append('-DOLD_MAP_NO_IMMUTABLE=1')
        if mm.find(b' kLastInternalOnlyCid ') == -1:
            macros.append('-DNO_LAST_INTERNAL_ONLY_CID=1')
        # Remove TypeRef https://github.com/dart-lang/sdk/commit/2ee6fcf5148c34906c04c2ac518077c23891cd1b
        # in this commit also added RecordType as sub class of AbstractType
        #   so assume Dart Records implementation is completed in this commit (before this commit is inconplete RecordType)
        if mm.find(b'V(TypeRef)') != -1:
            macros.append('-DHAS_TYPE_REF=1')
        # in main branch, RecordType is added in Dart 3.0 while TypeRef is removed in Dart 3.1
        # in Dart 2.19, RecordType might be added to a source code but incomplete
        if dart_version.startswith('3.') and mm.find(b'V(RecordType)') != -1:
            macros.append('-DHAS_RECORD_TYPE=1')
    
    with open(os.path.join(vm_path, 'class_table.h'), 'rb') as f:
        mm = mmap.mmap(f.fileno(), 0, access = mmap.ACCESS_READ)
        # Clean up ClassTable (Merge ClassTable and SharedClassTable back together)
        # https://github.com/dart-lang/sdk/commit/4a4eedd860a8af2b1cb27e68d9feae5550d0f511
        # the commit moved GetUnboxedFieldsMapAt() from SharedClassTable to ClassTable
        if mm.find(b'class SharedClassTable {') != -1:
            macros.append('-DHAS_SHARED_CLASS_TABLE=1')
    
    with open(os.path.join(vm_path, 'stub_code_list.h'), 'rb') as f:
        mm = mmap.mmap(f.fileno(), 0, access = mmap.ACCESS_READ)
        # Add InitLateStaticField and InitLateFinalStaticField stub
        # https://github.com/dart-lang/sdk/commit/37d45743e11970f0eacc0ec864e97891347185f5
        if mm.find(b'V(InitLateStaticField)') == -1:
            macros.append('-DNO_INIT_LATE_STATIC_FIELD=1')
    
    with open(os.path.join(vm_path, 'object_store.h'), 'rb') as f:
        mm = mmap.mmap(f.fileno(), 0, access = mmap.ACCESS_READ)
        # [vm] Simplify and optimize method extractors
        # https://github.com/dart-lang/sdk/commit/b9b341f4a71b3ac8c9810eb24e318287798457ae#diff-545efb05c0f9e7191a855bca5e463f8f7f68079f74056f0040196c666b3bb8f0
        if mm.find(b'build_generic_method_extractor_code)') == -1:
            macros.append('-DNO_METHOD_EXTRACTOR_STUB=1')

    with open(os.path.join(vm_path, 'object.h'), 'rb') as f:
        mm = mmap.mmap(f.fileno(), 0, access = mmap.ACCESS_READ)
        # [vm] Refactor access to Integer value
        # https://github.com/dart-lang/sdk/commit/84fd647969f0d74ab63f0994d95b5fc26cac006a
        if mm.find(b'AsTruncatedInt64Value()') == -1:
            macros.append('-DUNIFORM_INTEGER_ACCESS=1')
    
    if no_analysis:
        macros.append('-DNO_CODE_ANALYSIS=1')
    
    return macros

def cmake_blutter(input: BlutterInput):
    blutter_dir = os.path.join(SCRIPT_DIR, 'blutter')
    builddir = os.path.join(BUILD_DIR, input.blutter_name)
    
    macros = find_compat_macro(input.dart_info.version, input.no_analysis)
    my_env = None
    if platform.system() == 'Darwin':
        mac_ver = int(platform.mac_ver()[0].split('.', 1)[0])
        if mac_ver < 15:
            llvm_path = subprocess.run(['brew', '--prefix', 'llvm@16'], capture_output=True, check=True).stdout.decode().strip()
            clang_file = os.path.join(llvm_path, 'bin', 'clang')
            my_env = {**os.environ, 'CC': clang_file, 'CXX': clang_file+'++'}
    # cmake -GNinja -Bbuild -DCMAKE_BUILD_TYPE=Release
    subprocess.run([CMAKE_CMD, '-GNinja', '-B', builddir, f'-DDARTLIB={input.dart_info.lib_name}', f'-DNAME_SUFFIX={input.name_suffix}', '-DCMAKE_BUILD_TYPE=Release', '--log-level=NOTICE'] + macros, cwd=blutter_dir, check=True, env=my_env)

    # build and install blutter
    subprocess.run([NINJA_CMD], cwd=builddir, check=True)
    subprocess.run([CMAKE_CMD, '--install', '.'], cwd=builddir, check=True)

def get_dart_lib_info(libapp_path: str, libflutter_path: str) -> DartLibInfo:
    # getting dart version
    dart_version, snapshot_hash, flags, arch, os_name = extract_dart_info(libapp_path, libflutter_path)
    print(f'Dart version: {dart_version}, Snapshot: {snapshot_hash}, Target: {os_name} {arch}')
    print('flags: ' + ' '.join(flags))

    has_compressed_ptrs = 'compressed-pointers' in flags
    return DartLibInfo(dart_version, os_name, arch, has_compressed_ptrs, snapshot_hash)

# blutter 构建产物仓库：GitHub 主源 + Gitee 国内镜像
GITHUB_RELEASE_REPO = 'fvgfgtxdeujv/blutter_build_actions'
GITEE_RELEASE_REPO = 'qeruiop_admin/blutter_build_actions'


def get_ubuntu_info():
    # 读取 /etc/os-release 获取发行版 ID 与主版本号（如 Ubuntu 22.04 -> ('ubuntu', '22')）
    try:
        with open('/etc/os-release', 'r') as f:
            content = f.read()
        m_id = re.search(r'^ID="?([a-zA-Z]+)"?', content, re.M)
        m_ver = re.search(r'^VERSION_ID="?([\d.]+)"?', content, re.M)
        distro = m_id.group(1) if m_id else None
        major = m_ver.group(1).split('.')[0] if m_ver else None
        return distro, major
    except Exception:
        return None, None


def is_supported_environment():
    # 仅支持 Ubuntu 22.04 或 24.04
    distro, major = get_ubuntu_info()
    return distro == 'ubuntu' and major in ('22', '24')


def get_system_timezone():
    # 读取系统时区（优先 TZ 环境变量，其次 /etc/timezone，最后 date 命令）
    tz = os.environ.get('TZ')
    if tz:
        return tz.strip()
    try:
        with open('/etc/timezone', 'r') as f:
            return f.read().strip()
    except Exception:
        pass
    try:
        out = subprocess.run(['date', '+%Z'], capture_output=True, text=True, timeout=5)
        return out.stdout.strip()
    except Exception:
        return None


def measure_github_latency(timeout=10):
    # 用 curl 测试 github.com 的响应时间（秒 -> 毫秒），失败返回 None
    try:
        out = subprocess.run(
            ['curl', '-o', '/dev/null', '-s', '-w', '%{time_total}',
             '--connect-timeout', '5', '-m', str(timeout), 'https://github.com'],
            capture_output=True, text=True, timeout=timeout + 2)
        return float(out.stdout.strip()) * 1000
    except Exception:
        return None


CN_TIMEZONES = ('Asia/Shanghai', 'Asia/Chongqing', 'Asia/Urumqi',
                'Asia/Harbin', 'Asia/Macau', 'Asia/Hong_Kong', 'Asia/Taipei', 'PRC')


def detect_region():
    # 综合语言、时区、GitHub 延迟判断网络区域，返回 'gitee'（国内）或 'github'
    score = 0
    # 1. 语言：系统语言含中文（如 zh_CN）计 1 分
    lang = ' '.join(os.environ.get(k, '') for k in ('LANG', 'LC_ALL', 'LANGUAGE'))
    if re.search(r'zh[-_.]', lang, re.I):
        print(f"语言: {lang.strip() or '未知'} -> 中文环境")
        score += 1
    # 2. 时区：中国时区计 1 分
    tz = get_system_timezone()
    if tz and any(cn in tz for cn in CN_TIMEZONES):
        print(f"时区: {tz} -> 国内时区")
        score += 1
    # 3. GitHub 延迟：响应时间大于阈值（800ms）计 1 分
    latency = measure_github_latency()
    if latency is not None:
        print(f"GitHub 延迟: {latency:.0f} ms")
        if latency > 800:
            score += 1
    region = 'gitee' if score >= 2 else 'github'
    print(f"区域判定: 国内信号 {score}/3 -> 使用 {region}")
    return region


def download_blutter_binary(input: BlutterInput) -> bool:
    # 按区域选择主源（国内 Gitee / 国外 GitHub），失败自动切换到备选源
    ver = input.dart_info.version
    distro, major = get_ubuntu_info()
    base = f'blutter_dartvm{ver}_android_arm64'

    region = detect_region()
    if region == 'gitee':
        hosts = [
            f'https://gitee.com/{GITEE_RELEASE_REPO}/releases/download',
            f'https://github.com/{GITHUB_RELEASE_REPO}/releases/download',
        ]
    else:
        hosts = [
            f'https://github.com/{GITHUB_RELEASE_REPO}/releases/download',
            f'https://gitee.com/{GITEE_RELEASE_REPO}/releases/download',
        ]

    urls = []
    for host in hosts:
        if os.name == 'nt':
            # Windows 平台产物带 _win 后缀（releases 附件，运行时 dll 从仓库 build/ 目录下载）
            urls.append(f'{host}/{ver}/{base}_win.exe')
        if major in ('22', '24'):
            urls.append(f'{host}/{ver}/{base}_{major}')
        urls.append(f'{host}/{ver}/{base}')

    os.makedirs(BIN_DIR, exist_ok=True)
    for url in urls:
        try:
            print(f"正在下载: {url}")
            r = requests.get(url, timeout=180)
            if r.status_code != 200:
                print(f"  HTTP {r.status_code}，尝试下一个地址")
                continue
            with open(input.blutter_file, 'wb') as f:
                f.write(r.content)
            os.chmod(input.blutter_file, 0o755)
            print(f"下载完成: {input.blutter_file}")
            return True
        except Exception as e:
            print(f"  下载出错: {e}")
    return False


# Windows 运行依赖 dll（capstone + ICU，与 Dart 版本无关），存放于构建仓库 build/ 目录
WIN_RUN_DLLS = ('capstone.dll', 'icuuc73.dll', 'icudt73.dll')


def get_build_raw_hosts():
    # 按区域返回构建仓库 build/ 目录的 raw 下载地址（国内 Gitee 优先，国外 GitHub 优先）
    region = detect_region()
    if region == 'gitee':
        return [
            f'https://gitee.com/{GITEE_RELEASE_REPO}/raw/master/build',
            f'https://raw.githubusercontent.com/{GITHUB_RELEASE_REPO}/master/build',
        ]
    return [
        f'https://raw.githubusercontent.com/{GITHUB_RELEASE_REPO}/master/build',
        f'https://gitee.com/{GITEE_RELEASE_REPO}/raw/master/build',
    ]


def ensure_win_dlls() -> bool:
    # 仅 Windows 平台需要；检查 bin 目录 dll，缺失则从构建仓库 build/ 目录下载
    if os.name != 'nt':
        return True
    missing = [d for d in WIN_RUN_DLLS if not os.path.isfile(os.path.join(BIN_DIR, d))]
    if not missing:
        return True
    print(f"缺少 Windows 运行依赖 dll: {', '.join(missing)}，尝试从构建仓库 build/ 目录下载...")
    os.makedirs(BIN_DIR, exist_ok=True)
    ok = True
    for dll in missing:
        got = False
        for base in get_build_raw_hosts():
            url = f'{base}/{dll}'
            try:
                print(f"正在下载: {url}")
                r = requests.get(url, timeout=180)
                if r.status_code == 200:
                    with open(os.path.join(BIN_DIR, dll), 'wb') as f:
                        f.write(r.content)
                    print(f"下载完成: {os.path.join(BIN_DIR, dll)}")
                    got = True
                    break
                print(f"  HTTP {r.status_code}，尝试下一个地址")
            except Exception as e:
                print(f"  下载出错: {e}")
        if not got:
            ok = False
            print(f"下载失败: {dll}")
    return ok


def build_and_run(input: BlutterInput):
    # 检查 bin 目录是否存在对应版本的 blutter 二进制
    # 不存在时不自动构建，先确认系统受支持，再尝试从 Releases 自动下载
    if not os.path.isfile(input.blutter_file):
        print("=" * 60)
        print(f"未找到对应版本的 blutter 二进制: {input.blutter_file}")
        print(f"该 APK 使用的 Dart 版本为: {input.dart_info.version}")
        if not is_supported_environment():
            distro, major = get_ubuntu_info()
            print(f"当前系统或当前系统版本不支持（当前: {distro or '未知系统'} {major or ''}），仅支持 Ubuntu 22.04 或 24.04。")
            print("=" * 60)
            sys.exit(1)
        print("尝试从 Releases 自动下载匹配的二进制...")
        if download_blutter_binary(input):
            print("自动下载完成，开始解析。")
        else:
            print("自动下载失败。请手动从 blutter 构建仓库的 Releases 下载")
            print(f"例如 blutter_dartvm{input.dart_info.version}_android_arm64（或带 _22/_24 后缀），")
            print(f"放入 {BIN_DIR} 目录后，重新运行本命令即可解析。")
            print("=" * 60)
            sys.exit(1)

    # 创建 Visual Studio solution 前也需确保运行依赖 dll 存在（调试目录会复制 dll）
    if not ensure_win_dlls():
        print("=" * 60)
        print(f"Windows 运行依赖 dll 下载失败，请从构建仓库 build/ 目录手动下载：")
        print(f"  {' / '.join(WIN_RUN_DLLS)}")
        print(f"  放入 {BIN_DIR} 目录后，重新运行本命令即可解析。")
        print("=" * 60)
        sys.exit(1)

    # creating Visual Studio solution overrides building
    if input.create_vs_sln:
        macros = find_compat_macro(input.dart_info.version, input.no_analysis)
        blutter_dir = os.path.join(SCRIPT_DIR, 'blutter')
        dbg_output_path = os.path.abspath(os.path.join(input.outdir, 'out'))
        dbg_cmd_args = f'-i {input.libapp_path} -o {dbg_output_path}'

        vscmd_ver = os.getenv('VSCMD_VER')
        assert vscmd_ver is not None, "Need run blutter in Visual Studio Develeper console"
        if vscmd_ver.startswith('18.'):
            generator = 'Visual Studio 18 2026'
        elif vscmd_ver.startswith('17.'):
            generator = 'Visual Studio 17 2022'
        else:
            assert False, "Unknown Visual Studio version"

        subprocess.run([CMAKE_CMD, '-G', generator, '-A', 'x64', '-B', input.outdir, f'-DDARTLIB={input.dart_info.lib_name}', 
                        f'-DNAME_SUFFIX={input.name_suffix}', f'-DDBG_CMD:STRING={dbg_cmd_args}'] + macros + [blutter_dir], check=True)
        dbg_exe_dir = os.path.join(input.outdir, 'Debug')
        os.makedirs(dbg_exe_dir, exist_ok=True)
        for filename in glob.glob(os.path.join(BIN_DIR, '*.dll')):
            shutil.copy(filename, dbg_exe_dir)
    else:
        # execute blutter    
        subprocess.run([input.blutter_file, '-i', input.libapp_path, '-o', input.outdir], check=True)

def main_no_flutter(libapp_path: str, dart_version: str, outdir: str, rebuild_blutter: bool, create_vs_sln: bool, no_analysis: bool):
    version, os_name, arch = dart_version.split('_')
    dart_info = DartLibInfo(version, os_name, arch)
    input = BlutterInput(libapp_path, dart_info, outdir, rebuild_blutter, create_vs_sln, no_analysis)
    build_and_run(input)
    
def main2(libapp_path: str, libflutter_path: str, outdir: str, rebuild_blutter: bool, create_vs_sln: bool, no_analysis: bool):
    dart_info = get_dart_lib_info(libapp_path, libflutter_path)
    input = BlutterInput(libapp_path, dart_info, outdir, rebuild_blutter, create_vs_sln, no_analysis)
    build_and_run(input)

def main(indir: str, outdir: str, rebuild_blutter: bool, create_vs_sln: bool, no_analysis: bool):
    if indir.endswith(".apk"):
        with tempfile.TemporaryDirectory() as tmp_dir:
            libapp_file, libflutter_file = extract_libs_from_apk(indir, tmp_dir)
            main2(libapp_file, libflutter_file, outdir, rebuild_blutter, create_vs_sln, no_analysis)
    else:
        libapp_file, libflutter_file = find_lib_files(indir)
        main2(libapp_file, libflutter_file, outdir, rebuild_blutter, create_vs_sln, no_analysis)


if __name__ == "__main__":
    parser = argparse.ArgumentParser(
        prog='B(l)utter',
        description='Reversing a flutter application tool')
    # TODO: accept ipa
    parser.add_argument('indir', help='An apk or a directory that contains both libapp.so and libflutter.so')
    parser.add_argument('outdir', help='An output directory')
    parser.add_argument('--rebuild', action='store_true', default=False, help='Force rebuild the Blutter executable')
    parser.add_argument('--vs-sln', action='store_true', default=False, help='Generate Visual Studio solution at <outdir>')
    parser.add_argument('--no-analysis', action='store_true', default=False, help='Do not build with code analysis')
    # rare usage scenario
    parser.add_argument('--dart-version', help='Run without libflutter (indir become libapp.so) by specify dart version such as "3.4.2_android_arm64"')
    args = parser.parse_args()

    if args.dart_version is None:
        main(args.indir, args.outdir, args.rebuild, args.vs_sln, args.no_analysis)
    else:
        main_no_flutter(args.indir, args.dart_version, args.outdir, args.rebuild, args.vs_sln, args.no_analysis)
